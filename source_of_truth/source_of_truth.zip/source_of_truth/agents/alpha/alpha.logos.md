# alpha.logos.md

This is the identity and execution schema for agent Alpha.